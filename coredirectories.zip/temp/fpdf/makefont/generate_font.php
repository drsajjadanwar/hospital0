<?php
// generate_font.php

// Include the MakeFont script:
require_once('makefont.php');

// TTF file location, relative to this script:
$ttfFile = 'MyriadPro-Regular.ttf';

// Encoding (CP1252 is common for Western European languages)
$enc = 'CP1252';

// Set whether or not to embed the font
$embed = true;

// Now call MakeFont:
MakeFont($ttfFile, $enc, $embed);
?>
